import React from "react";

export class ToDoListWithInput extends React.Component {
    constructor() {
        super();
        this.state = {
            value: '',
            items: []
        }
    }

    addItem = (event) => {
        this.state.items.push(this.state.value)
        this.setState({items: this.state.items})
        event.preventDefault()
    }

    handleChange = (event) => {
        this.setState({value: event.target.value})
    }


    render() {
        const list = this.state.items.map((item, index) => {
            return <li key={index}>{item}</li>
        });

        return (
            <>
                <ul>
                    {list}
                </ul>
                <form onSubmit={(e) => this.addItem(e)}>
                    <input value={this.state.value}
                           onChange={(e) => this.handleChange(e)}/>
                    <input type='submit'/>
                </form>
            </>
        );
    }
}
