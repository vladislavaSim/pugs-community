 import React from "react";
export class Arrays extends React.Component {
    constructor() {
        super();
        this.state = {
            names: ['Коля', 'Вася', 'Петя', 'Иван', 'Дима']
        }
    }
    addNew() {
        this.state.names.push('new');
        this.setState({names: this.state.names})
    }
    deleteName(num) {
        this.state.names.splice(num, 1);
        this.setState({names: this.state.names})
    }

    render() {
        const namesList = this.state.names.map((name, index) => {
            return <li key={index}>
                {name}                  <button onClick={this.deleteName.bind(this, index)}>delete</button>
            </li>
        })
        return (
            <ul>
                {namesList}
                <button onClick={this.addNew.bind(this)}>push</button>
            </ul>
        );
    }
}
