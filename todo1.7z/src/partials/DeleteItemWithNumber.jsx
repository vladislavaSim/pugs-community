import React from "react";

export class DeleteItemWithNumber extends React.Component {
    constructor() {
        super();
        this.state = {
            names: ['Коля', 'Вася', 'Петя', 'Иван', 'Дима'],
            num: 1
        }
    }

    handleChange = (e) => {
        this.setState({num: e.target.value})
    }

    deleteName = () => {
        this.setState({names: this.state.names.filter((item, index) => index + 1 !== Number(this.state.num))});
    };

    render() {
        const namesList = this.state.names.map((name, index) => {
            return <li key={index}>
                {name}
            </li>
        })
        return (
            <ul>
                {namesList}
                <input type='number' value={this.state.num} onChange={this.handleChange}/>
                <button onClick={this.deleteName}>delete</button>
            </ul>
        );
    }
}
