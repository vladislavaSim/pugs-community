export function Nav(props) {
    return (
        <div className="navs">
            { props.shouldDisplayNav ? (
                <>
                    <a href="https://www.instagram.com/vladislava_sim/">Insta</a>
                    <a href="https://www.facebook.com/simonova.vladislava/">Facebook</a>
                    <a href="https://twitter.com/vladislava_sim">Twitter</a>
                </>
            ) : null }
        </div>
    )
}