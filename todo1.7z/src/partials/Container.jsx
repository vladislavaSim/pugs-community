import { Modal } from './Modal'
import {Posts} from "./Posts";


export function Container (props) {
    return (
        <div className="container">
            <button className="open" onClick={() => props.setDisplay(true)}>click me!</button>
        <Posts />
            <Modal setDisplay={props.setDisplay} shouldDisplayModal={props.shouldDisplayModal}/>
        </div>
    )
}