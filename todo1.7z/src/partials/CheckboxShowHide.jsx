import React from "react";

export class CheckboxShowHide extends React.Component {
    constructor() {
        super();
        this.state = {
            checked: true
        };
    }

    handleChange = () => {
        this.setState({checked: !this.state.checked});
    }

    render() {
        return <div>
            {this.state.checked ? <p>The sun will rise and we will try again </p> : undefined}
            <input type='checkbox' checked={this.state.checked} onChange={this.handleChange}/>
        </div>;
    }
}