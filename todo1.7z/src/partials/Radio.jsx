import React from "react";

export class Radio extends React.Component {
    constructor() {
        super();
        this.state = {option: 'option1'};
    }

    //Изменяет this.state.option при изменении радио:
    handleRadioChange(event) {
        this.setState({option: event.target.value});
    }

    render() {
        return <div>

            <p>Ваш выбор: {this.state.option}</p>

            <input
                name="lang"
                type="radio"
                value="option1"
                checked={this.state.option == 'option1'}
                onChange={this.handleRadioChange.bind(this)}
            />

            <input
                name="lang"
                type="radio"
                value="option2"
                checked={this.state.option == 'option2'}

                onChange={this.handleRadioChange.bind(this)}
            />

        </div>;
    }
}