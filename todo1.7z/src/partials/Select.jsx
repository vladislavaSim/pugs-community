import React from "react";

export class Select extends React.Component {
    state = {
        value: 'Mustard'
    };

    handleChangeSelect = (e) => {
        this.setState({value: e.target.value})
        console.log(e.target.value)
    };

    render() {
        return (
            <div>
                <p>Adding sauce: {this.state.value}</p>
                <select value={this.state.value} onChange={this.handleChangeSelect}>
                    <option>Mustard</option>
                    <option>Ketchup</option>
                    <option>Mayonnaise</option>
                </select>
            </div>
        );
    }
}