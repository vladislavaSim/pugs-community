import React from "react";

export class Submit extends React.Component {
    state = {
        value: '',
        submittedText: '',
    }
    handleChange = (event) => {
        this.setState({ value: event.target.value });
        event.preventDefault();
    }
    handleSubmit = (event) => {
        this.setState({ submittedText: this.state.value });
        event.preventDefault();
    }
    render() {
        return (
            <form>
                <p>{this.state.submittedText}</p>
                <input type="text" onChange={this.handleChange} />
                <button type="submit" onClick={this.handleSubmit}>submit</button>
            </form>
        );
    }
}