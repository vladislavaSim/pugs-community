export function Footer () {
    return(
        <div className="footer">
            see ya
        </div>
    )
}