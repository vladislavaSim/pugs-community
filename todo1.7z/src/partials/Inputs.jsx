import React from 'react'
export class Inputs extends React.Component {
    constructor() {
        super();
        this.state = {
            value: ''
        }
    };

    handleChange = (event) => {
        this.setState({value: event.target.value});
    }

    render() {
        const [name, surname, thirdName] = this.state.value.split(' ')
        return(
            <>
                <p>{name}</p>
                <p>{surname}</p>
                <p>{thirdName}</p>
                <input onChange={(event) => this.handleChange(event)}/>
            </>
        )

    }
}