import React from "react";

export class NamesTable extends React.Component {
    constructor() {
        super();
        this.state = {
            users: [
                {name: 'Коля', age: 30},
                {name: 'Вася', age: 40},
                {name: 'Петя', age: 50},
            ],
            name: '',
            age: ''
        };
    };

        handleName = (e) => {
            this.setState({name: e.target.value})
        };

        handleAge= (e) => {
          this.setState({age: e.target.value})
      };

        addNewUser = () => {
            this.setState({users: [...this.state.users, {name: this.state.name, age: this.state.age}]})
        }

    render() {
        const table = this.state.users.map(item => {
            return <tr>
                <td>{item.name}, </td><td>{item.age}</td>
            </tr>
        });
        return(
            <>
                <table>
                    <tbody>{table}</tbody></table>
                <input value={this.state.name} onChange={this.handleName} type='text'/>
                <input value={this.state.age} onChange={this.handleAge} type='number'/>
                <button onClick={this.addNewUser}>add new user</button>
            </>
        )
    }
}