import React from "react";

export class Checkbox extends React.Component {
    constructor() {
        super();
        this.state = {
            checked: true
        };
    }

    handleChange = () => {
        this.setState({checked: !this.state.checked});
    }

    render() {
        return <div>
            <p>Add mayonnaise? {this.state.checked ? 'yep' : 'nope'}</p>
           <input type='checkbox' checked={this.state.checked} onChange={this.handleChange}/>
        </div>;
    }
}
