import  React from 'react';

export class Hiding extends React.Component {
    constructor() {
        super();
        this.state = {
            show: false,
            name: 'Иван',
            age: 25
        };
     }

     showName() {
        this.state.show ? this.setState({show: false}) : this.setState({show: true})
     }
    render() {
        let text;
        let textButton
        if(this.state.show) {
            textButton = 'hide'
            text = <p>{this.state.name}, {this.state.age}</p>
        } else {
            textButton = 'show'
        }
        return(
            <div>
                {text}
                <button onClick={this.showName.bind(this)}>{textButton}</button>
            </div>
        )
    }
}