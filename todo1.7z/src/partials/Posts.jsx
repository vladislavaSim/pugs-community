export function Posts(props) {
    return (
        <>
            <span>{props.title} </span>
            <span>{props.subtitle}</span>
        </>
    )
}