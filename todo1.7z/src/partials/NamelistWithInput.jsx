import React from "react";

export class NamelistWithInput extends React.Component {
    constructor() {
        super();
        this.state = {
            names: ['Olha', 'Viktor', 'Pavel', 'Olesya'],
            value: ''
        }
    }
    handleChange = (e) => {
        this.setState({value: e.target.value})
    };

    handleSubmit = (e) => {
        this.setState({names: [...this.state.names, this.state.value]});
        e.preventDefault();
    };

    deleteName = (deletedName) => {
        this.setState({names: this.state.names.filter((name) => name !== deletedName)});
    }

    render() {
        const nameList = this.state.names.map((name, index) => {
            return <li key={`${name}${index}`}>
                {name}
                <button onClick={() => this.deleteName(name)}>delete</button>
            </li>
        });
        return (
            <form onSubmit={this.handleSubmit}>
                <ul>{nameList}</ul>
                <input type='text' value={this.state.value} onChange={this.handleChange}/>
                <button type='submit'>add</button>
            </form>
        )
    }
}