import React from "react";

export class LinksList extends React.Component {
    constructor() {
        super();
        this.state = {
            hrefs: [
                {href: '1.html', text: 'ссылка 1'},
                {href: '2.html', text: 'ссылка 2'},
                {href: '3.html', text: 'ссылка 3'},
            ],
            newHref: '',
            newText: ''
        };
    }

    hrefFunc = (e) => {
        this.setState({newHref: e.target.value})
    };

    textFunc = (e) => {
        this.setState({newText: e.target.value})
    };

    addNewHref = (e) => {
        this.setState({hrefs: this.state.hrefs.push({href: this.state.newHref, text: this.state.newText})})
        e.preventDefault()
    }

    render() {
        let list = this.state.hrefs.map((href, index) => {
            return <li key={index}>
                <a href={href.href}>{href.text}</a>
            </li>
        })
        return (
            <>
                <ul>{list}</ul>
                <form>
                    <input type='text' value={this.state.newHref} onChange={(e) => {this.hrefFunc(e)}}/>
                    <input type='text' value={this.state.newText} onChange={(e) => {this.textFunc(e)}}/>
                    <button onClick={(e)=>{this.addNewHref(e)}}>add</button>
                </form>
            </>

        )
    }
}