import React from "react";

export class SubmitThreeInputs extends React.Component {
    state = {
        name: '',
        secondName: '',
        surname: '',
        submittedText: '',
    }
    handleChange1 = (event) => {
        this.setState({ name: event.target.value });
        event.preventDefault();
    };
    handleChange2 = (event) => {
        this.setState({ secondName: event.target.value });
        event.preventDefault();
    };
    handleChange3 = (event) => {
        this.setState({ surname: event.target.value });
        event.preventDefault();
    }
    handleSubmit = (event) => {
        this.setState({ submittedText: this.state.name + ' ' + this.state.secondName + ' ' + this.state.surname});
        event.preventDefault();
    }
    render() {
        return (
            <form>
                <p>ФИО: {this.state.submittedText}</p>
                <input type="text" onChange={this.handleChange1} />
                <input type="text" onChange={this.handleChange2} />
                <input type="text" onChange={this.handleChange3} />
                <button type="submit" onClick={this.handleSubmit}>submit</button>
            </form>
        );
    }
}