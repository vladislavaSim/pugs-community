import React from "react";

export class Textarea extends React.Component {
    constructor() {
        super();
        this.state = {
            value: ''
        };
    }

    handleChange = (event) => {
        this.setState({value: event.target.value});
    }

    render() {
        return <div>
            <textarea value={this.state.value} onChange={this.handleChange}>write here</textarea>
            <p>{this.state.value}</p>
        </div>;
    }
}
