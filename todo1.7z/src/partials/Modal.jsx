export function Modal(props) {
    return (
        <>
            { props.shouldDisplayModal ? (
            <div className='modal'>
                <button onClick={() => props.setDisplay(false)} className='close'>x</button>
                <div>hello</div>
                <div>there</div>
            </div>
            ) : null }
        </>
    )
}