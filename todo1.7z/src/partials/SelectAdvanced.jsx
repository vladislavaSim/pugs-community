import React from "react";

export class SelectAdvanced extends React.Component {
    state = {
        value: '0',
        sauces: ['Mustard', 'Ketchup', 'Mayonnaise', 'Sriracha', 'Soy Sauce']
    };

    handleChangeSelect = (e) => {
        this.setState({value: e.target.value})
    };

    render() {
        const options = this.state.sauces.map((item, index) => {
            return <option value={index}>{item}</option>
        })
        return (
            <div>
                <p>Adding sauce: {this.state.sauces[this.state.value]}</p>
                <select value={this.state.value} onChange={this.handleChangeSelect}>
                    {options}
                </select>
            </div>
        );
    }
}