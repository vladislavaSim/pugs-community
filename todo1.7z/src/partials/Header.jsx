import {Nav} from "./Nav";

export function Header(props) {
    return (
        <header className="header" >
            Welcome to the page meh
            <Nav shouldDisplayNav={props.shouldDisplayNav} />
        </header>
    );
}
