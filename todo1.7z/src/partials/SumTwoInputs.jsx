import React from "react";

export class SumTwoInputs extends React.Component {
    state = {
        sum: '',
        first: '',
        second: ''
    }


    firstNumChange = (e) => {
        this.setState({first: e.target.value})
        e.preventDefault();
    };
    secondNumChange = (e) => {
        this.setState({second: e.target.value})
        e.preventDefault();
    };
    handleSubmit = (e) => {
        this.setState({sum: parseInt(this.state.first) + parseInt(this.state.second)})
        e.preventDefault();
    }

    render() {
        return (
            <form>
               <p>{this.state.sum}</p>
                <input type="number" value={this.state.first}
                       onChange={(e) => this.firstNumChange(e)} />
                <input type="number" value={this.state.second}
                       onChange={(e) => this.secondNumChange(e)} />
                <button type="submit" onClick={this.handleSubmit}>submit</button>
            </form>
        );
    }
}