import './App.css';
import { useState } from "react";
import { Header } from './partials/Header';
import { Container } from "./partials/Container";
import { Footer } from "./partials/Footer";
import {SelectAdvanced} from "./partials/SelectAdvanced";
import {Radio} from "./partials/Radio";


function App() {
     const [displayNav, setDisplayNav] = useState(true); // [someValue, someFunctionToChangeValue]
    const [displayModal, displayFunc] = useState(false);
    return (
        <div className="App">
            <Header
                shouldDisplayNav={true}
            />
            <Radio />
            <Container
                shouldDisplayModal={displayModal}
                setDisplay={displayFunc} />
            <Footer />
        </div>
    );
}

export default App;
